package com.gpsrasgan.fees

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private val auth by lazy { FirebaseAuth.getInstance() }
    private val db by lazy { FirebaseFirestore.getInstance() }
    private var secondaryAuth: FirebaseAuth? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)

        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(FirebaseBridge(), "AndroidFirebase")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    private fun emailForUsername(username: String): String = username.trim().lowercase() + "@gpsrasgan.local"

    private fun jsCallback(function: String, json: JSONObject) {
        val safe = JSONObject.quote(json.toString())
        runOnUiThread { web.evaluateJavascript("window.$function($safe)", null) }
    }

    private fun getRoleAndProfile(onDone: (JSONObject?) -> Unit) {
        val u = auth.currentUser ?: return onDone(null)
        db.collection("users").document(u.uid).get().addOnSuccessListener { snap ->
            if (!snap.exists()) return@addOnSuccessListener onDone(null)
            val role = snap.getString("role") ?: return@addOnSuccessListener onDone(null)
            val out = JSONObject()
                .put("uid", u.uid)
                .put("role", role)
                .put("name", snap.getString("name") ?: "")
                .put("username", snap.getString("username") ?: "")
                .put("mobile", snap.getString("mobile") ?: "")
                .put("email", u.email ?: "")
            onDone(out)
        }.addOnFailureListener { onDone(null) }
    }

    private fun ensureSecondaryAuth(): FirebaseAuth? {
        if (secondaryAuth != null) return secondaryAuth
        val primary = FirebaseApp.getInstance()
        val name = "TeacherCreator"
        val secondary = try {
            FirebaseApp.getInstance(name)
        } catch (_: Exception) {
            FirebaseApp.initializeApp(this, primary.options, name)
        }
        secondaryAuth = FirebaseAuth.getInstance(secondary)
        return secondaryAuth
    }

    inner class FirebaseBridge {
        @JavascriptInterface
        fun login(username: String, password: String) {
            val clean = username.trim()
            if (clean.isEmpty() || password.isEmpty()) {
                jsCallback("onNativeLogin", JSONObject().put("ok", false).put("message", "Username और Password जरूरी है"))
                return
            }
            // Username is mapped to the app's internal Firebase email alias.
            auth.signInWithEmailAndPassword(emailForUsername(clean), password)
                .addOnSuccessListener { result ->
                    val user = result.user ?: return@addOnSuccessListener jsCallback("onNativeLogin", JSONObject().put("ok", false).put("message", "User नहीं मिला"))
                    db.collection("users").document(user.uid).get().addOnSuccessListener { snap ->
                        val role = snap.getString("role")
                        if (role == null) {
                            auth.signOut()
                            jsCallback("onNativeLogin", JSONObject().put("ok", false).put("message", "User profile नहीं मिला"))
                        } else {
                            jsCallback("onNativeLogin", JSONObject()
                                .put("ok", true)
                                .put("uid", user.uid)
                                .put("name", snap.getString("name") ?: clean)
                                .put("username", snap.getString("username") ?: clean)
                                .put("role", role)
                            )
                        }
                    }.addOnFailureListener {
                        auth.signOut()
                        jsCallback("onNativeLogin", JSONObject().put("ok", false).put("message", "Profile load नहीं हुआ"))
                    }
                }
                .addOnFailureListener { jsCallback("onNativeLogin", JSONObject().put("ok", false).put("message", "Firebase login असफल")) }
        }

        @JavascriptInterface
        fun createTeacher(name: String, username: String, password: String, mobile: String) {
            getRoleAndProfile { profile ->
                if (profile?.optString("role") != "admin") {
                    jsCallback("onTeacherCreated", JSONObject().put("ok", false).put("message", "केवल Admin Teacher बना सकता है"))
                    return@getRoleAndProfile
                }
                val cleanUser = username.trim()
                if (cleanUser.isEmpty() || password.length < 6 || name.trim().isEmpty()) {
                    jsCallback("onTeacherCreated", JSONObject().put("ok", false).put("message", "Name, Username और 6+ character Password जरूरी है"))
                    return@getRoleAndProfile
                }
                val email = emailForUsername(cleanUser)
                val sec = ensureSecondaryAuth()
                if (sec == null) {
                    jsCallback("onTeacherCreated", JSONObject().put("ok", false).put("message", "Firebase secondary account तैयार नहीं हुआ"))
                    return@getRoleAndProfile
                }
                sec.createUserWithEmailAndPassword(email, password).addOnSuccessListener { result ->
                    val teacher = result.user ?: return@addOnSuccessListener jsCallback("onTeacherCreated", JSONObject().put("ok", false).put("message", "Teacher account नहीं बना"))
                    val data = hashMapOf<String, Any>(
                        "name" to name.trim(),
                        "username" to cleanUser,
                        "role" to "teacher",
                        "mobile" to mobile.trim(),
                        "email" to email
                    )
                    db.collection("users").document(teacher.uid).set(data)
                        .addOnSuccessListener {
                            sec.signOut()
                            jsCallback("onTeacherCreated", JSONObject().put("ok", true).put("uid", teacher.uid).put("username", cleanUser))
                        }
                        .addOnFailureListener { e ->
                            teacher.delete()
                            sec.signOut()
                            jsCallback("onTeacherCreated", JSONObject().put("ok", false).put("message", "Teacher profile save नहीं हुआ: ${e.message}"))
                        }
                }.addOnFailureListener { e ->
                    jsCallback("onTeacherCreated", JSONObject().put("ok", false).put("message", "Teacher account नहीं बना: ${e.message ?: "Username पहले से मौजूद हो सकता है"}"))
                }
            }
        }

        @JavascriptInterface
        fun listUsers() {
            getRoleAndProfile { profile ->
                if (profile?.optString("role") != "admin") {
                    jsCallback("onUsersLoaded", JSONObject().put("ok", false).put("message", "Admin access required"))
                    return@getRoleAndProfile
                }
                db.collection("users").get().addOnSuccessListener { snap ->
                    val arr = JSONArray()
                    snap.documents.forEach { d ->
                        arr.put(JSONObject()
                            .put("uid", d.id)
                            .put("name", d.getString("name") ?: "")
                            .put("username", d.getString("username") ?: "")
                            .put("role", d.getString("role") ?: "")
                            .put("mobile", d.getString("mobile") ?: "")
                        )
                    }
                    jsCallback("onUsersLoaded", JSONObject().put("ok", true).put("users", arr))
                }.addOnFailureListener { e -> jsCallback("onUsersLoaded", JSONObject().put("ok", false).put("message", e.message ?: "Users load failed")) }
            }
        }

        @JavascriptInterface
        fun deleteTeacher(uid: String) {
            getRoleAndProfile { profile ->
                if (profile?.optString("role") != "admin") {
                    jsCallback("onTeacherDeleted", JSONObject().put("ok", false).put("message", "केवल Admin"))
                    return@getRoleAndProfile
                }
                db.collection("users").document(uid).get().addOnSuccessListener { snap ->
                    if (!snap.exists() || snap.getString("role") != "teacher") {
                        jsCallback("onTeacherDeleted", JSONObject().put("ok", false).put("message", "Teacher नहीं मिला"))
                        return@addOnSuccessListener
                    }
                    db.collection("users").document(uid).delete()
                        .addOnSuccessListener { jsCallback("onTeacherDeleted", JSONObject().put("ok", true).put("uid", uid)) }
                        .addOnFailureListener { e -> jsCallback("onTeacherDeleted", JSONObject().put("ok", false).put("message", e.message ?: "Delete failed")) }
                }
            }
        }
    }

    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
